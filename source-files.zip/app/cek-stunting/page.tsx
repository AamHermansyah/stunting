'use client';

import StuntingCheckForm from '@/components/pages/cek-stunting/StuntingCheckForm'
import React from 'react'

function CekStuntingPage() {
  return (
    <div>
      <StuntingCheckForm />
    </div>
  )
}

export default CekStuntingPage