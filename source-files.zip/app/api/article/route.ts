import { json } from '@/lib/json'
import { prisma } from '@/db'

export async function POST(req: Request) {
  const data = await req.json();

  try {
    const createdResume = await prisma.article.create({
      data: {
        ...data
      },
    });

    return new Response(json({
      message: 'Data successfully created',
      status: 201,
      data: createdResume
    }));

  } catch (error) {
    console.error('Error creating resume:', error);
    return new Response(json({ message: 'Internal server error', status: 500 }));
  } finally {
    await prisma.$disconnect();
  }
}